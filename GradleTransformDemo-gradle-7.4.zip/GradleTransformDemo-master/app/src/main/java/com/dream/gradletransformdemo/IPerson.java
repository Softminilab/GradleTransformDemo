package com.dream.gradletransformdemo;

public interface IPerson {
    String getName();
}