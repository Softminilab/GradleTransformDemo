package com.dream.customtransformplugin

import org.objectweb.asm.MethodVisitor
import org.objectweb.asm.Opcodes
import org.objectweb.asm.commons.AdviceAdapter

/**
 * 自定义 MethodVisitor，用于在方法入口和出口插入 Trace 代码。
 */
class AUtoInstrumentationMethodVisitor(
    api: Int,
    methodVisitor: MethodVisitor?,
    access: Int,
    name: String?,
    descriptor: String?
) : AdviceAdapter(api, methodVisitor, access, name, descriptor) {

    private var methodName: String = name ?: "unknownMethodName"

    override fun onMethodEnter() {
        // 方法开始时插入 "我来了****" 的打印语句
        mv.visitFieldInsn(Opcodes.GETSTATIC, "java/lang/System", "out", "Ljava/io/PrintStream;")
        mv.visitLdcInsn("我来了****")
        mv.visitMethodInsn(Opcodes.INVOKEVIRTUAL, "java/io/PrintStream", "println", "(Ljava/lang/String;)V", false)


        // 方法开始时插入 Trace.beginSection(methodName)
        print("方法开始时插入 methodName: $methodName")
        mv.visitLdcInsn(methodName)
        mv.visitMethodInsn(Opcodes.INVOKESTATIC, "android/os/Trace", "beginSection", "(Ljava/lang/String;)V", false)
    }

    override fun onMethodExit(opcode: Int) {
        // 方法结束时插入 Trace.endSection()
        mv.visitMethodInsn(Opcodes.INVOKESTATIC, "android/os/Trace", "endSection", "()V", false)
    }

    override fun visitMaxs(maxStack: Int, maxLocals: Int) {
        super.visitMaxs(maxStack + 4, maxLocals + 4)
    }
}