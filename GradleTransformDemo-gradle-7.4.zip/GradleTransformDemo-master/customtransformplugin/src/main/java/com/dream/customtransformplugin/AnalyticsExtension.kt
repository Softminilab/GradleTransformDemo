package com.dream.customtransformplugin
/**
 *  控制是否开启自动插桩的 Extension 类
 */
open class AnalyticsExtension {
    var disableAutoTrack: Boolean = false
}