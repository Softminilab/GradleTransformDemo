package com.dream.customtransformplugin

import com.android.build.api.transform.*
import com.android.build.gradle.internal.pipeline.TransformManager
import org.objectweb.asm.ClassReader
import org.objectweb.asm.ClassWriter
import java.io.File
import java.io.FileOutputStream
import java.util.HashMap
import java.util.jar.JarFile
import java.util.jar.JarOutputStream
import java.util.zip.ZipEntry

/**
 * 自定义 Transform，用于修改字节码，实现自动插桩。
 */
class AutoInstrumentationTransform(private val analyticsExtension: AnalyticsExtension) : Transform() {

    override fun getName(): String {
        return "AutoInstrumentationTransform"
    }

    override fun getInputTypes(): MutableSet<QualifiedContent.ContentType> {
        return TransformManager.CONTENT_CLASS
    }

    override fun getScopes(): MutableSet<in QualifiedContent.Scope> {
        return mutableSetOf(QualifiedContent.Scope.PROJECT)
    }

    override fun isIncremental(): Boolean {
        return false // 暂时禁用增量构建
    }

    override fun transform(transformInvocation: TransformInvocation) {
        transformInvocation.inputs.forEach { input ->
            // 处理 Jar 输入
            input.jarInputs.forEach { jarInput ->
                handleJarInput(jarInput, transformInvocation)
            }

            // 处理 Directory 输入
            input.directoryInputs.forEach { directoryInput ->
                handleDirectoryInput(transformInvocation.context, directoryInput, transformInvocation.outputProvider)
            }
        }
    }


    /**
     * 处理 Jar 输入的逻辑
     */
    private fun handleJarInput(jarInput: JarInput, transformInvocation: TransformInvocation) {
        val dest = transformInvocation.outputProvider.getContentLocation(
            jarInput.file.absolutePath,
            jarInput.contentTypes,
            jarInput.scopes,
            Format.JAR
        )

        if (!jarInput.file.isFile) return

        val jarFile = JarFile(jarInput.file)
        val jarOutputStream = JarOutputStream(FileOutputStream(dest))
        val enumeration = jarFile.entries()

        while (enumeration.hasMoreElements()) {
            val jarEntry = enumeration.nextElement()
            val inputStream = jarFile.getInputStream(jarEntry)

            jarOutputStream.putNextEntry(ZipEntry(jarEntry.name))
            val bytes = inputStream.readBytes()
            val entryName = jarEntry.name

            if (entryName.endsWith(".class") && shouldInstrumentClass(entryName)) {
                val classReader = ClassReader(bytes)
                val classWriter = ClassWriter(classReader, ClassWriter.COMPUTE_FRAMES)
                val classVisitor = AutoInstrumentationClassVisitor(classWriter)
                classReader.accept(classVisitor, ClassReader.EXPAND_FRAMES)
                val modifiedBytes = classWriter.toByteArray()
                jarOutputStream.write(modifiedBytes)
                println("------AutoInstrumentationTransform modifyJar entryName = $entryName, output: ${dest.absolutePath}")

            } else {
                jarOutputStream.write(bytes)
            }
            jarOutputStream.closeEntry()
            inputStream.close()
        }
        jarOutputStream.close()
        jarFile.close()
    }

    /**
     * 处理  编译 Directory 输入的逻辑
     */
    private fun handleDirectoryInput(context: Context, directoryInput: DirectoryInput, outputProvider: TransformOutputProvider) {
        println("== AutoInstrumentationTransform  handleDirectoryInput directoryInputs = " + directoryInput.file.listFiles()?.joinToString { it.absolutePath})
        val inputDir = directoryInput.file
        val outputDir = outputProvider.getContentLocation(
            directoryInput.name,
            directoryInput.contentTypes,
            directoryInput.scopes,
            Format.DIRECTORY
        )

        inputDir.walk().forEach { file ->
            if (file.isFile && file.name.endsWith(".class") && shouldInstrumentClass(file.absolutePath)) {
                println("-----AutoInstrumentationTransform modifyClassFile dir =${inputDir.absolutePath} \nclassFile= ${file.absolutePath} \ntemporaryDir = ${context.temporaryDir} \ndisableAutoTrack = ${analyticsExtension.disableAutoTrack}")


                val relativePath = file.absolutePath.substring(inputDir.absolutePath.length + 1)
                val outputFile = outputDir.resolve(relativePath)

                outputFile.parentFile?.mkdirs()

                val classReader = ClassReader(file.readBytes())
                val classWriter = ClassWriter(classReader, ClassWriter.COMPUTE_FRAMES)
                val classVisitor = AutoInstrumentationClassVisitor(classWriter)
                classReader.accept(classVisitor, ClassReader.EXPAND_FRAMES)

                outputFile.writeBytes(classWriter.toByteArray())
                // println("------AutoInstrumentationTransform modifyClassFile  output: ${outputFile.absolutePath}")
            }
        }
        println("✅ 完成了")
    }
    /**
     * 修改 class 文件, 这里只做插桩操作，不负责临时文件的写入操作
     */
    private fun modifyClassFile(dir: File, classFile: File, temporaryDir: File): File? {
        val classReader = ClassReader(classFile.readBytes())
        val classWriter = ClassWriter(classReader, ClassWriter.COMPUTE_FRAMES)
        val classVisitor = AutoInstrumentationClassVisitor(classWriter)
        classReader.accept(classVisitor, ClassReader.EXPAND_FRAMES)

        val modifiedFile = File(temporaryDir, classFile.name)
        modifiedFile.writeBytes(classWriter.toByteArray())
        return  modifiedFile
    }

    /**
     *  判断是否需要插桩的类
     */
    private fun shouldInstrumentClass(className: String): Boolean {
        return  className.contains("com/dream/gradletransformdemo/")
                && !className.contains("$")  // 排除内部类
                && !className.startsWith("androidx/") // 排除 androidx
                && !className.startsWith("kotlin/") // 排除 kotlin
                && !className.startsWith("kotlinx/") // 排除 kotlinx
                && !className.startsWith("kotlin/jvm/") // 排除 kotlin jvm
                && !className.startsWith("com/google/") // 排除 google
                && !className.startsWith("com/android/") // 排除 android
    }
}