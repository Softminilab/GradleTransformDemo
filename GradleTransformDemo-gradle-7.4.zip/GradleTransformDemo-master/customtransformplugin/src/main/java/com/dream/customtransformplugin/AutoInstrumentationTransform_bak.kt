package com.dream.customtransformplugin

import com.android.build.api.transform.*
import com.android.build.gradle.internal.pipeline.TransformManager
import org.objectweb.asm.ClassReader
import org.objectweb.asm.ClassWriter
import java.io.File

class AutoInstrumentationTransform_bak : Transform() {
    override fun getName(): String {
        return "AutoInstrumentationTransform_bak"
    }

    override fun getInputTypes(): MutableSet<QualifiedContent.ContentType> {
        return TransformManager.CONTENT_CLASS
    }

    override fun getScopes(): MutableSet<in QualifiedContent.Scope> {
        return TransformManager.SCOPE_FULL_PROJECT
    }

    override fun isIncremental(): Boolean {
        return false
    }

    override fun transform(transformInvocation: TransformInvocation) {
        transformInvocation.inputs.forEach { input ->
            input.jarInputs.forEach { jarInput ->
                // 处理 jar 输入
            }

            input.directoryInputs.forEach { directoryInput ->
                val inputDir = directoryInput.file
                val outputDir = transformInvocation.outputProvider.getContentLocation(
                    directoryInput.name,
                    directoryInput.contentTypes,
                    directoryInput.scopes,
                    Format.DIRECTORY
                )


                inputDir.walk().forEach { file ->
                    if (file.isFile && file.name.endsWith(".class")) {
                        print("\n*********************")
                        println("\n打印文件名称：${file.absolutePath}")
                        print("\n*********************\n")


                        // 计算相对于输入目录的相对路径
                        val relativePath = file.absolutePath.substring(inputDir.absolutePath.length + 1)

                        val outputFile = outputDir.resolve(relativePath)


                        // 创建父目录（如果不存在）
                        outputFile.parentFile?.mkdirs()


                        val classReader = ClassReader(file.readBytes())
                        //  使用 EXPAND_FRAMES 参数
                        val classWriter = ClassWriter(classReader, ClassWriter.COMPUTE_MAXS)
                        val classVisitor = AutoInstrumentationClassVisitor(classWriter)
                        classReader.accept(classVisitor, ClassReader.EXPAND_FRAMES)
                        outputFile.writeBytes(classWriter.toByteArray())

                        println("outputFile: $outputFile")
                    }
                }
                println("✅ 完成了")
            }
        }
    }
}