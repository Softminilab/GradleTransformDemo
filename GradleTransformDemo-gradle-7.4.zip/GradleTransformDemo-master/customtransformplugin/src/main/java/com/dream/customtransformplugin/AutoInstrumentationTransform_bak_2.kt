package com.dream.customtransformplugin

import com.android.build.api.transform.*
import com.android.build.gradle.internal.pipeline.TransformManager
import org.objectweb.asm.ClassReader
import org.objectweb.asm.ClassWriter
import java.io.File
import java.io.FileOutputStream
import java.util.jar.JarFile
import java.util.jar.JarOutputStream
import java.util.zip.ZipEntry

/**
 * 自定义 Transform，用于修改字节码，实现自动插桩。
 */
class AutoInstrumentationTransform_bak_2 : Transform() {

    override fun getName(): String {
        return "AutoInstrumentationTransform_bak_2"
    }

    override fun getInputTypes(): MutableSet<QualifiedContent.ContentType> {
        return TransformManager.CONTENT_CLASS
    }

    override fun getScopes(): MutableSet<in QualifiedContent.Scope> {
        return TransformManager.SCOPE_FULL_PROJECT
    }

    override fun isIncremental(): Boolean {
        return false // 暂时禁用增量构建
    }

    override fun transform(transformInvocation: TransformInvocation) {
        transformInvocation.inputs.forEach { input ->
            // 处理 Jar 输入
            input.jarInputs.forEach { jarInput ->
//                handleJarInput(jarInput, transformInvocation)
            }

            // 处理 Directory 输入
            input.directoryInputs.forEach { directoryInput ->
                handleDirectoryInput(directoryInput, transformInvocation)
            }
        }
    }

    /**
     * 处理 Jar 输入的逻辑
     */
    private fun handleJarInput(jarInput: JarInput, transformInvocation: TransformInvocation) {
        val dest = transformInvocation.outputProvider.getContentLocation(
            jarInput.file.absolutePath,
            jarInput.contentTypes,
            jarInput.scopes,
            Format.JAR
        )

        if (jarInput.file.isFile) {
            val jarFile = JarFile(jarInput.file)
            val jarOutputStream = JarOutputStream(FileOutputStream(dest))
            val enumeration = jarFile.entries()

            while (enumeration.hasMoreElements()) {
                val jarEntry = enumeration.nextElement()
                val inputStream = jarFile.getInputStream(jarEntry)

                jarOutputStream.putNextEntry(ZipEntry(jarEntry.name))

                val bytes = inputStream.readBytes()
                val entryName = jarEntry.name
                if (entryName.endsWith(".class") && shouldInstrumentClass(entryName)) {
                    val classReader = ClassReader(bytes)
                    val classWriter = ClassWriter(classReader, ClassWriter.COMPUTE_FRAMES)
                    val classVisitor = AutoInstrumentationClassVisitor(classWriter)
                    classReader.accept(classVisitor, ClassReader.EXPAND_FRAMES)
                    jarOutputStream.write(classWriter.toByteArray())

                } else {
                    jarOutputStream.write(bytes)
                }
                jarOutputStream.closeEntry()
                inputStream.close()
            }
            jarOutputStream.close()
            jarFile.close()
        }
    }


    /**
     * 处理 Directory 输入的逻辑
     */
    private fun handleDirectoryInput(directoryInput: DirectoryInput, transformInvocation: TransformInvocation) {
        val inputDir = directoryInput.file
        val outputDir = transformInvocation.outputProvider.getContentLocation(
            directoryInput.name,
            directoryInput.contentTypes,
            directoryInput.scopes,
            Format.DIRECTORY
        )

        inputDir.walk().forEach { file ->
            if (file.isFile && file.name.endsWith(".class")) {
                print("\n*********************")
                println("\n打印文件名称：${file.absolutePath}")
                print("\n*********************\n")


                // 计算相对于输入目录的相对路径
                val relativePath = file.absolutePath.substring(inputDir.absolutePath.length + 1)

                val outputFile = outputDir.resolve(relativePath)


                // 创建父目录（如果不存在）
                outputFile.parentFile?.mkdirs()


                val classReader = ClassReader(file.readBytes())
                //  使用 EXPAND_FRAMES 参数
                val classWriter = ClassWriter(classReader, ClassWriter.COMPUTE_MAXS)
                val classVisitor = AutoInstrumentationClassVisitor(classWriter)
                classReader.accept(classVisitor, ClassReader.EXPAND_FRAMES)
                outputFile.writeBytes(classWriter.toByteArray())

                println("outputFile: $outputFile")
            }
        }
        println("✅ 完成了")
    }

    /**
     *  判断是否需要插桩的类
     */
    private fun shouldInstrumentClass(className: String): Boolean {
        val targetPackage = "com/dream/gradletransformdemo"
        return className.startsWith(targetPackage) && !className.contains("$") &&
                className.endsWith(".class")

    }
}