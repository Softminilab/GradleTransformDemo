package com.dream.customtransformplugin

import com.android.build.gradle.AppExtension
import org.gradle.api.Plugin
import org.gradle.api.Project

/**
 * 自定义 Gradle 插件，用于注册字节码转换 Transform。
 */
class CustomTransformPlugin : Plugin<Project> {

    override fun apply(project: Project) {
        println("Hello CustomTransformPlugin")

        // 创建并配置 AnalyticsExtension
        val analyticsExtension = project.extensions.create("analyticsExtension", AnalyticsExtension::class.java)

        // 配置 Android AppExtension，注册 Transform
        project.extensions.configure(AppExtension::class.java) { appExtension ->
            appExtension.registerTransform(AutoInstrumentationTransform(analyticsExtension))
        }
    }
}