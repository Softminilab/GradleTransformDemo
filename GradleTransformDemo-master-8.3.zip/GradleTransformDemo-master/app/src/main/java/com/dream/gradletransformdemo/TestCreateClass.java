package com.dream.gradletransformdemo;

public class TestCreateClass {

    public static  void main(String[] args){
    }
}