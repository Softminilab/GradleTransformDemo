package com.dream.customtransformplugin

import org.objectweb.asm.ClassVisitor
import org.objectweb.asm.MethodVisitor
import org.objectweb.asm.Opcodes

class AutoInstrumentationClassVisitor(
    classVisitor: ClassVisitor,
    private val analyticsExtension: AnalyticsExtension
) : ClassVisitor(Opcodes.ASM9, classVisitor) {


    override fun visitMethod(
        access: Int,
        name: String?,
        descriptor: String?,
        signature: String?,
        exceptions: Array<out String>?
    ): MethodVisitor {
        val methodVisitor = super.visitMethod(access, name, descriptor, signature, exceptions)
        val shouldInstrument = name != null && descriptor != null && shouldInstrumentMethod(name)
        println("visitMethod name: $name descriptor: $descriptor shouldInstrument: $shouldInstrument")
        return if (shouldInstrument){
            AUtoInstrumentationMethodVisitor(Opcodes.ASM9, methodVisitor, access, name, descriptor)
        }else {
            methodVisitor
        }
    }


    /**
     * 判断是否需要插桩的方法
     */
    private  fun shouldInstrumentMethod(methodName: String): Boolean {
        val shouldInstrument = !methodName.startsWith("lambda") &&
                !methodName.equals("<init>") &&
                !methodName.equals("<clinit>")

        println("shouldInstrumentMethod: $methodName, result: $shouldInstrument")
        return shouldInstrument
    }

}