package com.dream.customtransformplugin

import com.android.build.api.instrumentation.AsmClassVisitorFactory
import com.android.build.api.instrumentation.ClassContext
import com.android.build.api.instrumentation.ClassData
import com.android.build.api.instrumentation.InstrumentationParameters
import org.gradle.api.tasks.Input
import org.objectweb.asm.ClassVisitor
import org.objectweb.asm.Opcodes

abstract class AutoInstrumentationTransform : AsmClassVisitorFactory<AutoInstrumentationTransform.Parameters> {

    interface Parameters : InstrumentationParameters {
        @get:Input
        val analyticsExtension: org.gradle.api.provider.Property<AnalyticsExtension>
    }

    override fun createClassVisitor(classContext: ClassContext, nextClassVisitor: ClassVisitor): ClassVisitor {
        return AutoInstrumentationClassVisitor(nextClassVisitor, parameters.get().analyticsExtension.get())
    }

    override fun isInstrumentable(classData: ClassData): Boolean {
        return shouldInstrumentClass(classData.className)
    }


    private fun shouldInstrumentClass(className: String): Boolean {
        val shouldInstrument =  className.contains("com.dream.gradletransformdemo")
                && !className.contains("$")  // 排除内部类
        println("shouldInstrumentClass: $className, result: $shouldInstrument")
        return shouldInstrument
    }

}