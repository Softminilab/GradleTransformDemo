package com.dream.customtransformplugin

import com.android.build.api.variant.AndroidComponentsExtension
import org.gradle.api.Plugin
import org.gradle.api.Project
import com.android.build.api.instrumentation.InstrumentationScope // 确保导入

/**
 * 自定义 Gradle 插件，用于注册字节码转换 Transform。
 */
class CustomTransformPlugin : Plugin<Project> {

    override fun apply(project: Project) {
        println("Hello CustomTransformPlugin")

        // 创建并配置 AnalyticsExtension
        val analyticsExtension = project.extensions.create("analyticsExtension", AnalyticsExtension::class.java)

        // 获取 AndroidComponentsExtension 并注册 Transform
        val androidComponents = project.extensions.getByType(AndroidComponentsExtension::class.java)
        androidComponents.onVariants { variant ->
            variant.instrumentation.transformClassesWith(
                AutoInstrumentationTransform::class.java,
                InstrumentationScope.ALL // 确保能找到 InstrumentationScope
            ){
                it.analyticsExtension.set(analyticsExtension)
            }
        }
    }
}